//
// Created by lopez on 5/7/2021.
//

#ifndef UI_H
#define UI_H

#include "../tl/Controller.h"

class Ui{
private:
    Controller controller;
public:
    void imprimirMenu();
};

#endif //TRABAJO_DE_INVESTIGACION1_UI_H
