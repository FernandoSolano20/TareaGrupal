//
// Created by lopez on 5/7/2021.
//

#include "Ui.h"
#include <iostream>
using namespace std;

void Ui::imprimirMenu() {
    cout <<"Bienvenido al sistema de listas circulares y de doble enlace.\n"
           "Seleccione la opcion a trabajar: \n"
           "1. Agregar datos a la lista circular.\n"
           "2. Buscar un valor en la lista circular\n"
           "3. Eliminar un valor de la lista circular\n"
           "4. Ver datos en lista circular.\n"
           "5.Agragar un valor a la lista con doble enlace.\n"
           "6. Buscar un valor en la lista con doble enlace.\n"
           "7. Eliminar un valor de la lista con doble enlace.\n"
           "8. Ver datos en lista con doble enlace.\n"
           "9. Salir.\n";
}


